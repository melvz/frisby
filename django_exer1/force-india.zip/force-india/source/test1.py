print "deng!"

x = 1
y = 2

ab = x + y
print ab
print "beng beng!"
